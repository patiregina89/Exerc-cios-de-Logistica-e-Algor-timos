#Função menu cliente:
def menu_cliente():
    print('___MENU CLIENTES___\n'
        '1 - Cadastrar Cliente\n'
        '2 - Buscar Cliente\n'
        '3 - Listar Cliente\n'
        '4 - Alterar Cliente\n'
        '5 - Excluir Cliente\n'
        '6 - Backup Cliente\n'
        '0 - Sair\n'
        'Digite a opção desejada: ')
    return input()

#Função validar menu cliente:
def validar_menu_cliente():
    while True:
        opcao = menu_cliente()
        if opcao == '1':
            cadastro_cliente()
        elif opcao == '2':
            cpf_c = input('Digite o CPF do cliente: ')
            buscar_cliente(cpf_c)
        elif opcao == '3':
            listar_cliente()
        elif opcao == '4':
            cpf_c = input('Digite o CPF do cliente: ')
            alterar_cliente(cpf_c)
        elif opcao == '5':
            cpf_c = input('Digite o CPF do cliente: ')
            excluir_cliente(cpf_c)
        elif opcao == '6':
            copia_cliente()
        else:
            print('Programa finalizado!!        :)')
            break

#Função cadastrar cliente
def cadastro_cliente():
    try:
        arquivo = open('Dados_Clientes.txt', 'a')
        print('Cadastrar Cliente')
        cpf_c = input('CPF: ')
        nome_c = input('Nome completo: ').title()
        nascimento_c = input('Data de nascimento: ')
        telefone_c = input('Telefone: ')
        endereco_c = input('Endereço: ')
        arquivo.write(cpf_c + ' # ' + nome_c + ' # ' + nascimento_c + ' # ' + telefone_c + ' # ' + endereco_c + '\n')
        arquivo.close()
        print('Cliente cadastrado com sucesso!        :) \n')
    except IOError as error:
        print('Erro: ', error)

#Função pesquisar cliente
def buscar_cliente(cpf_c):
    cliente_buscado = buscar_cliente_retorno(cpf_c)
    if cliente_buscado != None:
        print('Cliente encontrado -->  ' + cliente_buscado + '\n')
    else:
        print('Cliente não encontrado!        :/')
        cadastro_cliente()


def buscar_cliente_retorno(cpf_c):
    try:
        arquivo = open('Dados_Clientes.txt', 'r+')
        contador = 0
        for linha in arquivo:
            linha = linha.rstrip()
            if cpf_c in linha:
                contador += 1
                return linha
            else:
                return None
        arquivo.close()
    except IOError as error:
        print('Erro: ', error)


#Função Listar Cliente
def listar_cliente():
    try:
        arquivo = open('Dados_Clientes.txt', 'r+')
        print('Lista de clientes: ')
        for linhas in arquivo:
            linhas = linhas.rstrip()
            print(linhas)
        arquivo.close()
        print('\n')
    except IOError as erro:
        print('Erro: ', erro)

#Função alterar cliente
def alterar_cliente(cpf_c):
    try:
        with open('Dados_Clientes.txt', 'r') as arquivo:
            linhas = arquivo.readlines()
            for elemento in linhas:
                if elemento.startswith(cpf_c):
                    print('Alterar Cliente: ')
                    cpf_c = input('CPF: ')
                    nome_c = input('Nome completo: ').title()
                    nascimento_c = input('Data de nascimento: ')
                    telefone_c = input('Telefone: ')
                    endereco_c = input('Endereço: ')
                    pos = linhas.index(elemento)
                    item_c = (cpf_c + ' # ' + nome_c + ' # ' + nascimento_c + ' # ' + telefone_c + ' # ' + endereco_c + '\n')
                    linhas.pop(pos)
                    linhas.insert(pos, item_c)
                    arquivo = open('Dados_Clientes.txt', 'w')
                    arquivo.writelines(linhas)
                    arquivo.close()
                    print('Alteração realizada com sucesso!        :)')
                    print('\n')
    except IOError as erro:
        print('Erro: ', erro)

#Função excluir cliente
def excluir_cliente(cpf_c):
    try:
        arquivo = open('Dados_Clientes.txt', 'r')
        linhas = arquivo.readlines()
        for elemento in linhas:
            if elemento.startswith(cpf_c):
                pos = linhas.index(elemento)
                linhas.pop(pos)
                arquivo = open('Dados_Clientes.txt', 'w')
                arquivo.writelines(linhas)
        arquivo.close()
        print('Cliente removido com sucesso!        :)\n')
        return 0
    except IOError as error:
        print('Erro', error)

#funcao backup cliente
def copia_cliente():
    try:
        arquivo1 = open('Dados_Clientes.txt', 'r')
        arquivo2 = open('Copia_Dados_Clientes.txt', 'w')
        for texto in arquivo1:
            arquivo2.write(texto)
        arquivo1.close()
        arquivo2.close()
        print('Backup realizado com sucesso!        :)\n')
    except IOError as error:
        print('ERRO: ', error)

