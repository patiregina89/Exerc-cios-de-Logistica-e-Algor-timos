#funcao menu do produto
def menu_produto():
    print('___MENU PRODUTO___\n'
        '1 - Cadastrar Produto\n'
        '2 - Buscar Produto\n'
        '3 - Listar Produto\n'
        '4 - Alterar Produto\n'
        '5 - Excluir Produto\n'
        '6 - Backup Produto\n'
        '0 - Sair\n'
        'Digite a opção desejada: ')
    return input()

#funcao validação do menu do produto
def validar_menu_produto():
    while True:
        opcao = menu_produto()
        if opcao == '1':
            cadastro_produto()
        elif opcao == '2':
            cod_p = input('Digite o código do produto: ')
            buscar_produto(cod_p)
        elif opcao == '3':
            listar_produto()
        elif opcao == '4':
            cod_p = input('Digite o código do produto: ')
            alterar_produto(cod_p)
        elif opcao == '5':
            cod_p = input('Digite o código do produto: ')
            excluir_produto(cod_p)
        elif opcao == '6':
            copia_produto()
        else:
            print('Programa Finalizado!        :)')
            break


#funcao cadastro produto
def cadastro_produto():
    try:
        arquivo = open('Dados_Produtos.txt', 'a')
        print('Cadastrar Produto: ')
        cod_p = input('Código: ')
        nome_p = input('Nome: ').title()
        preco_p = input('Preço: ')
        cod_for = input('Código Fornecedor: ')
        quant_p = input('Quantidade:')
        arquivo.write(cod_p + ' # ' + nome_p + ' # ' + preco_p + ' # ' + cod_for + ' # ' + quant_p +'\n')
        arquivo.close()
        print('Produto cadastrado com sucesso!        :)')
    except IOError as error:
        print('Erro: ', error)

#funcao pesquisar produto
def buscar_produto(cod_p):
    produto_buscado = buscar_produto_retorno(cod_p)
    if produto_buscado != None:
        print('Produto encontrado -->  ' + produto_buscado + '\n')
    else:
        print('Produto não encontrado!        :/')


def buscar_produto_retorno(cod_p):
    try:
        arquivo = open('Dados_Produtos.txt', 'r+')
        contador = 0
        for linha in arquivo:
            linha = linha.rstrip()
            if cod_p in linha:
                contador += 1
                return linha
            else:
                return None
        arquivo.close()
    except IOError as error:
        print('Erro: ', error)


#funcao listar produto
def listar_produto():
    try:
        arquivo = open('Dados_Produtos.txt', 'r+')
        print('Lista de produtos:')
        for linhas in arquivo:
            linhas = linhas.rstrip()
            linhas_lista = linhas.split(' # ')
            print(linhas_lista[1],' = código: ', linhas_lista[0], '/ Preço: ', linhas_lista[2], '/ Quantidade: ', linhas_lista[4])
        arquivo.close()
        print('\n--------- \n')
    except IOError as error:
        print('Erro: ', error)


#funcao alterar produto
def alterar_produto(cod_p):
    try:
        with open('Dados_Produtos.txt', 'r') as arquivo:
            linhas = arquivo.readlines()
            for elemento in linhas:
                if elemento.startswith(cod_p):
                    print('Alterar Produto: ')
                    cod_p = input('Código Produto: ')
                    nome_p = input('Nome: ').title()
                    preco_p = input('Preço: ')
                    cod_for = input('Código Fornecedor: ')
                    quant_p = input('Quantidade:')
                    item_p = (cod_p + ' # ' + nome_p + ' # ' + preco_p + ' # ' + cod_for + ' # ' + quant_p + '\n')
                    pos = linhas.index(elemento)
                    linhas.pop(pos)
                    linhas.insert(pos, item_p)
                    arquivo = open('Dados_Produtos.txt', 'w')
                    arquivo.writelines(linhas)
                    arquivo.close()
                    print('Alteração realizada com sucesso!        :)')
                    print('\n')
    except IOError as error:
        print('Erro: ', error)

# funcao excluir produto
def excluir_produto(cod_p):
    try:
        arquivo = open('Dados_Produtos.txt', 'r')
        linhas = arquivo.readlines()
        for elemento in linhas:
            if elemento.startswith(cod_p):
                pos = linhas.index(elemento)
                linhas.pop(pos)
                arquivo = open('Dados_Produtos.txt', 'w')
                arquivo.writelines(linhas)
        arquivo.close()
        print('Produto removido com sucesso!        :) \n')
        return 0
    except IOError as error:
        print('ERRO: ', error)


#funcao copia produtos
def copia_produto():
    try:
        arquivo1 = open('Dados_Produtos.txt', 'r')
        arquivo2 = open('Copia_Dados_Produtos.txt', 'a')
        for texto in arquivo1:
            arquivo2.write(texto)
        arquivo1.close()
        arquivo2.close()
        print('Arquivo dados produto copiado com sucesso!        :)')
    except IOError as error:
        print('ERRO: ', error)

