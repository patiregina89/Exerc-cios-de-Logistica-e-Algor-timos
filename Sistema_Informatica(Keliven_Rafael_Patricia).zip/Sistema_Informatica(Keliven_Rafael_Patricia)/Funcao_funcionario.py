#funcao menu do funcionário
def menu_funcionario():
    print('___MENU FUNCIONÁRIO___\n'
        '1 - Cadastrar Funcionário\n'
        '2 - Buscar Funcionário\n'
        '3 - Listar Funcionário\n'
        '4 - Alterar Funcionário\n'
        '5 - Excluir Funcionário\n'
        '6 - Backup Funcionário\n'
        '0 - Sair\n'
        'Digite a opção desejada: ')
    return input()

#funcao validação do menu do funcionario
def validar_menu_funcionario():
    while True:
        opcao = menu_funcionario()
        if opcao == '1':
            cadastro_funcionario()
        elif opcao == '2':
            cpf_f = input('Digite o CPF do funcionário: ')
            buscar_funcionario(cpf_f)
        elif opcao == '3':
            listar_funcionario()
        elif opcao == '4':
            cpf_f = input('Digite o CPF do funcionário: ')
            alterar_funcionario(cpf_f)
        elif opcao == '5':
            cpf_f = input('Digite o CPF do funcionário: ')
            excluir_funcionario(cpf_f)
        elif opcao == '6':
            copia_funcionario()
        else:
            print('Programa Finalizado!        :)')
            break


#funcao cadastro cliente
def cadastro_funcionario():
    try:
        arquivo = open('Dados_Funcionarios.txt', 'a')
        print('Cadastrar Funcionário: ')
        cpf_f = input('CPF: ')
        nome_f = input('Nome completo: ').title()
        nascimento_f = input('Data de Nascimento: ')
        telefone_f = input('Telefone: ')
        endereco_f = input('Endereço: ')
        salario_f = input('Salário: ')
        cargo_f = input('Cargo: ')
        contratacao_f = input('Data de contratação: ')
        arquivo.write(cpf_f + ' # ' + nome_f + ' # ' + nascimento_f + ' # ' + telefone_f + ' # ' + endereco_f +
                      ' # ' + salario_f + ' # ' + cargo_f + ' # ' + contratacao_f + '\n')
        arquivo.close()
        print('Funcionário cadastrado com sucesso!        :) \n')
    except IOError as error:
        print('Erro: ', error)

#funcao pesquisar funcionario
def buscar_funcionario(cpf_f):
    try:
        arquivo = open('Dados_Funcionarios.txt', 'r+')
        contador= 0
        for linha in arquivo:
            linha = linha.rstrip()
            if cpf_f in linha:
                contador +=1
                print('Funcionário encontrado -->  ' + linha + '\n')
            else:
                print('Funcionário não encontrado!        :/') #ESTÁ DANDO ERRO!! MESMO LOCALIZANDO O FUNCIONARIO ENTRA NA MSG E PEDE CADASTRO
                #cadastro_funcionario()
        arquivo.close()
    except IOError as error:
        print('Erro: ', error)


#funcao listar funcionario
def listar_funcionario():
    try:
        arquivo = open('Dados_Funcionarios.txt', 'r+')
        print('Lista de funcionários: ')
        for linhas in arquivo:
            linhas = linhas.rstrip()
            print(linhas)
        arquivo.close()
        print('\n')
    except IOError as error:
        print('Erro: ', error)


#funcao alterar funcionario
def alterar_funcionario(cpf_f):
    try:
        with open('Dados_Funcionarios.txt', 'r') as arquivo:
            linhas = arquivo.readlines()
            for elemento in linhas:
                if elemento.startswith(cpf_f):
                    print('Alterar Funcionario: ')
                    cpf_f = input('CPF: ')
                    nome_f = input('Nome completo: ').title()
                    nascimento_f = input('Data de Nascimento: ')
                    telefone_f = input('Telefone: ')
                    endereco_f = input('Endereço: ')
                    salario_f = input('Salário: ')
                    cargo_f = input('Cargo: ')
                    contratacao_f = input('Data de contratação: ')
                    item_f = (cpf_f + ' # ' + nome_f + ' # ' + nascimento_f + ' # ' + telefone_f + ' # ' + endereco_f +
                              ' # ' + salario_f + ' # ' + cargo_f + ' # ' + contratacao_f + '\n')
                    pos = linhas.index(elemento)
                    linhas.pop(pos)
                    linhas.insert(pos, item_f)
                    arquivo = open('Dados_Funcionarios.txt', 'w')
                    arquivo.writelines(linhas)
                    arquivo.close()
                    print('Alteração realizada com sucesso!        :)')
                    print('\n')
    except IOError as error:
        print('Erro: ', error)

# funcao excluir funcionario
def excluir_funcionario(cpf_f):
    try:
        arquivo = open('Dados_Funcionarios.txt', 'r')
        linhas = arquivo.readlines()
        for elemento in linhas:
            if elemento.startswith(cpf_f):
                pos = linhas.index(elemento)
                linhas.pop(pos)
                arquivo = open('Dados_Funcionarios.txt', 'w')
                arquivo.writelines(linhas)
        arquivo.close()
        print('Funcionário removido com sucesso!        :)\n')
        return 0
    except IOError as error:
        print('ERRO: ', error)


#funcao copia funcionario
def copia_funcionario():
    try:
        arquivo1 = open('Dados_Funcionarios.txt', 'r')
        arquivo2 = open('Copia_Dados_Funcionarios.txt', 'a')
        for texto in arquivo1:
            arquivo2.write(texto)
        arquivo1.close()
        arquivo2.close()
        print('Arquivo dados funcionário copiado com sucesso!        :)')
    except IOError as error:
        print('ERRO: ', error)

