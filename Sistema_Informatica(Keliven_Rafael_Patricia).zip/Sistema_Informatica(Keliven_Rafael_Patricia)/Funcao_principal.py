from Funcao_cliente import*
from Funcao_fornecedor import*
from Funcao_produto import*
from Funcao_funcionario import*
from Funcao_estoque import*

#funcao menu principal
def menu_principal():
    print('___MENU PRINCIPAL__\n'
        '1 - Área Cliente\n'
        '2 - Área Fornecedor\n'
        '3 - Área Produto\n'
        '4 - Área Funcionário\n'
        '5 - Área Estoque\n'
        '6 - Emissão Nota Fiscal\n'
        'Digite a opção desejada: ')
    return input()

#funcao validação do menu principal
def validar_menu_principal():
    while True:
        opcao = menu_principal()
        if opcao == '1':
            validar_menu_cliente()
        elif opcao == '2':
            validar_menu_fornecedor()
        elif opcao == '3':
            validar_menu_produto()
        elif opcao == '4':
            validar_menu_funcionario()
        elif opcao == '5':
            validar_menu_estoque()
        elif opcao == '6':
            emissao_nf()
        else:
            print('Programa Finalizado!        :)')
            break


def cabecalho_nf():
    print(('*' * 66))
    print('*'*26, 'NOTA FISCAL', '*'*26)
    print('LOJA DE INFORMÁTICA-LTDA    -    CNPJ 01.657.816/0001-00')
    print('End: Rua da Esperança, nº 10  -  Bairro: Milagre, Florianópolis/SC')
    print('CEP: 88000-000       Telefone: (48) 3333-3333')
    print('Natureza da Operação: Venda de Mercadoria')
    print(('*'*66))


def emissao_nf():
    try:
        arquivo = open('Nota_Fiscal.txt', 'a')
        input_cpf = input('CPF Cliente: ')
        linha_cliente = buscar_cliente_retorno(input_cpf)
        input_venda = input('Código da venda: ')
        linha_venda = buscar_venda_retorno(input_venda)
        cabecalho = cabecalho_nf()
        arquivo.write(cabecalho + '\n' + linha_cliente + '\n' + linha_venda + '\n')
        arquivo.close()
    except IOError as error:
        print('Erro: ', error)

validar_menu_principal()
validar_menu_cliente()
validar_menu_produto()
validar_menu_estoque()
validar_menu_funcionario()
validar_menu_fornecedor()
emissao_nf()
