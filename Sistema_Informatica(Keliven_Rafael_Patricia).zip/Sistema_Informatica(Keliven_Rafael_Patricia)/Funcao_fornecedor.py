#funcao menu do fornecedor
def menu_fornecedor():
    print('___MENU FORNECEDOR___\n'
        '1 - Cadastrar Fornecedor\n'
        '2 - Pesquisar Fornecedor\n'
        '3 - Listar Fornecedor\n'
        '4 - Alterar Fornecedor\n'
        '5 - Excluir Fornecedor\n'
        '6 - Backup Fornecedor\n'
        '0 - Sair\n'
        'Digite a opção desejada: ')
    return input()

#funcao validação do menu do fornecedor
def validar_menu_fornecedor():
    while True:
        opcao = menu_fornecedor()
        if opcao == '1':
            cadastro_fornecedor()
        elif opcao == '2':
            cod_for = input('Digite o código do fornecedor: ')
            buscar_fornecedor(cod_for)
        elif opcao == '3':
            listar_fornecedor()
        elif opcao == '4':
            cod_for = input('Digite o código do fornecedor: ')
            alterar_fornecedor(cod_for)
        elif opcao == '5':
            cod_for = input('Digite o código do fornecedor: ')
            excluir_fornecedor(cod_for)
        elif opcao == '6':
            copia_fornecedor()
        else:
            print('Programa Finalizado!        :)')
            break

#funcao cadastro fornecedor
def cadastro_fornecedor():
    try:
        arquivo = open('Dados_Fornecedor.txt', 'a')
        print('Cadastrar Fornecedor: ')
        cod_for = input('Código: ')
        cnpj_for = input('CNPJ: ')
        nome_for = input('Nome: ').title()
        telefone_for = input('Telefone: ')
        email_for = input('E-mail: ')
        arquivo.write(cod_for + ' # ' + cnpj_for + ' # ' + nome_for + ' # ' + telefone_for + ' # ' + email_for + '\n')
        arquivo.close()
        print('Fornecedor cadastrado com sucesso!        :) \n')
    except IOError as error:
        print('Erro: ', error)

#funcao pesquisar fornecedor
def buscar_fornecedor(cod_for):
    try:
        arquivo = open('Dados_Fornecedor.txt', 'r+')
        contador= 0
        for linha in arquivo:
            linha = linha.rstrip()
            if cod_for in linha:
                contador +=1
                print('Fornecedor encontrado -->  ' + linha + '\n')
            else:
                print('Fornecedor não encontrado!        :/') #ESTÁ DANDO ERRO!! MESMO LOCALIZANDO O FORNECEDOR ENTRA NA MSG E PEDE CADASTRO
                #cadastro_fornecedor()
        arquivo.close()
    except IOError as error:
        print('Erro: ', error)

#funcao listar fornecedor
def listar_fornecedor():
    try:
        arquivo = open('Dados_Fornecedor.txt', 'r+')
        print('Lista de fornecedores:')
        for linhas in arquivo:
            linhas = linhas.rstrip()
            print(linhas)
        arquivo.close()
        print('\n')
    except IOError as error:
        print('Erro: ', error)


#funcao alterar fornecedor
def alterar_fornecedor(cod_for):
    try:
        with open('Dados_Fornecedor.txt', 'r') as arquivo:
            linhas = arquivo.readlines()
            for elemento in linhas:
                if elemento.startswith(cod_for):
                    print('Alterar Fornecedor: ')
                    cod_for = input('Código fornecedor: ')
                    cnpj_for = input('CNPJ: ')
                    nome_for = input('Nome: ').title()
                    telefone_for = input('Telefone: ')
                    email_for = input('E-mail: ')
                    item_for = (cod_for + ' # ' + cnpj_for + ' # ' + nome_for + ' # ' + telefone_for + ' # ' + email_for + '\n')
                    pos = linhas.index(elemento)
                    linhas.pop(pos)
                    linhas.insert(pos, item_for)
                    arquivo = open('Dados_Fornecedor.txt', 'w')
                    arquivo.writelines(linhas)
                    arquivo.close()
                    print('Alteração realizada com sucesso!        :)')
                    print('\n')
    except IOError as error:
        print('Erro: ', error)

# funcao excluir fornecedor
def excluir_fornecedor(cod_for):
    try:
        arquivo = open('Dados_Fornecedor.txt', 'r')
        linhas = arquivo.readlines()
        for elemento in linhas:
            if elemento.startswith(cod_for):
                pos = linhas.index(elemento)
                linhas.pop(pos)
                arquivo = open('Dados_Fornecedor.txt', 'w')
                arquivo.writelines(linhas)
        arquivo.close()
        print('Fornecedor removido com sucesso!        :)\n')
        return 0
    except IOError as error:
        print('ERRO: ', error)


#funcao copia fornecedor
def copia_fornecedor():
    try:
        arquivo1 = open('Dados_Fornecedor.txt', 'r')
        arquivo2 = open('Copia_Dados_Fornecedor.txt', 'a')
        for texto in arquivo1:
            arquivo2.write(texto)
        arquivo1.close()
        arquivo2.close()
        print('Arquivo dados fornecedor copiado com sucesso!        :) \n')
    except IOError as error:
        print('ERRO: ', error)

