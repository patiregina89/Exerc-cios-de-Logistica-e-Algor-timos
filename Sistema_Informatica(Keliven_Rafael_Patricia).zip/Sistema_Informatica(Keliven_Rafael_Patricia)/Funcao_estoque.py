from Funcao_cliente import*
from Funcao_produto import*

def menu_estoque():
    print('GERENCIADOR DE ESTOQUE \n'
          '1 - Registro de Venda para Cliente\n'
          '2 - Relatório de Vendas\n' #Listar venda
          '3 - Comprar Produto do Fornecedor\n'
          '4 - Relatório de Compra de Produto \n' #Listar compra
          '5 - Controle de estoque de produtos \n'
          '0 - Sair\n'
          'Digite a opção desejada: ')
    return input()

    # Função validar menu venda:
def validar_menu_estoque():
    while True:
        opcao = menu_estoque()
        if opcao == '1':
            registro_venda()
        elif opcao == '2':
            relatorio_venda()
        elif opcao == '3':
            comprar_produto()
        elif opcao == '4':
            relatorio_compra()
        elif opcao == '5':
            controle_estoque()
        else:
            print('Programa finalizado!        :)')
            break

#Função registro de vendas para Cliente
def registro_venda():
    try:
        arquivo = open('Dados_vendas.txt', 'a')
        print('Registro de Vendas para Cliente:')
        input_cpf = input('CPF Cliente: ')
        linha_cliente = buscar_cliente_retorno(input_cpf)

        cod_venda = input('Informe o código da venda: ')
        cod_p = input('Código do produto: ')
        buscar_produto_retorno(cod_p)
        quant_p = input('Quantidade: ')
        arquivo.write(linha_cliente + ' # ' + cod_venda + ' # ' + cod_p + ' # ' + quant_p + '\n')
        arquivo.close()
        print('Venda registrada com sucesso!!        :)')
    except IOError as error:
        print('Erro: ', error)

#Função pesquisar cliente
def buscar_venda(cod_venda):
    venda_buscada = buscar_venda_retorno(cod_venda)
    if venda_buscada != None:
        print('Venda encontrada -->  ' + venda_buscada + '\n')
    else:
        print('Venda não encontrada!        :/')
        registro_venda()

def buscar_venda_retorno(cod_venda):
    try:
        arquivo = open('Dados_vendas.txt', 'r+')
        contador = 0
        for linha in arquivo:
            linha = linha.rstrip()
            if cod_venda in linha:
                contador += 1
                return linha
            else:
                return None
        arquivo.close()
    except IOError as error:
        print('Erro: ', error)

#Função relatório de vendas (listar vendas)
def relatorio_venda():
    try:
        arquivo = open('Dados_vendas.txt', 'r+')
        print('Relatório de vendas: \n')
        for linhas in arquivo:
            linhas = linhas.rstrip()
            print(linhas)
        arquivo.close()
    except IOError as erro:
        print('Erro: ', erro)


def comprar_produto():
    try:
        arquivo = open('Dados_compra.txt', 'a')
        print('Registro de Compras de Produtos:')
        cod_p = input('Código do produto: ')
        linha_produto = buscar_produto_retorno(cod_p)

        quant_p  = input('Quantidade produto: ')
        arquivo.write(linha_produto + ' # ' + cod_p + ' # ' + quant_p + '\n')
        arquivo.close()
        print('Compra registrada com sucesso!!        :)')
    except IOError as error:
        print('Erro: ', error)


#Função relatório de vendas (listar vendas)
def relatorio_compra():
    try:
        arquivo = open('Dados_compra.txt', 'r+')
        print('Relatório de Compras de produtos: \n')
        for linhas in arquivo:
            linhas = linhas.rstrip()
            print(linhas)
        arquivo.close()
    except IOError as erro:
        print('Erro: ', erro)

'''def controle_estoque():
    #receber o valor inicial cadastrado, add com novas qunatidades ou diminuir com as quantidades vendidas(criar uma variável para as 2 funções de calculo).
#quant_p[4] = quant_p[4] + ? 
'''